<?php
require "config/constants.php";
session_start();
if(isset($_SESSION["uid"])){
	header("location:profile.php");
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Taj Masala</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<link rel="stylesheet" type="text/css" href="style.css">
		<style></style>
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="#" class="navbar-brand"><img src="product_images\rsz_131aa4ad0-628d-45d4-9c67-3caa5ee22b18.jpg" style="width:180px;height:35px;></a>
			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Product</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>about us </a></li>
			</ul>
			<form class="navbar-form navbar-left">
		        <div class="form-group">
		          <input type="text" class="form-control" placeholder="Search" id="search">
		        </div>
		        <button type="submit" class="btn btn-primary" id="search_btn"><span class="glyphicon glyphicon-search"></span></button>
		     </form>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-shopping-cart"></span>Cart<span class="badge">0</span></a>
					<div class="dropdown-menu" style="width:400px;">
						<div class="panel panel-success">
							<div class="panel-heading">
								<div class="row">
									<div class="col-md-3">Sl.No</div>
									<div class="col-md-3">Product Image</div>
									<div class="col-md-3">Product Name</div>
									<div class="col-md-3">Price in <?php echo CURRENCY; ?></div>
								</div>
							</div>
							<div class="panel-body">
								<div id="cart_product">
								<!--<div class="row">
									<div class="col-md-3">Sl.No</div>
									<div class="col-md-3">Product Image</div>
									<div class="col-md-3">Product Name</div>
									<div class="col-md-3">Price in $.</div>
								</div>-->
								</div>
							</div>
							<div class="panel-footer"></div>
						</div>
					</div>
				</li>
				<li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span>SignIn</a>
					<ul class="dropdown-menu">
						<div style="width:300px;">
							<div class="panel panel-primary">
								<div class="panel-heading">Login</div>
								<div class="panel-heading">
									<form onsubmit="return false" id="login">
										<label for="email">Email</label>
										<input type="email" class="form-control" name="email" id="email" required/>
										<label for="email">Password</label>
										<input type="password" class="form-control" name="password" id="password" required/>
										<p><br/></p>
										<a href="#" style="color:white; list-style:none;">Forgotten Password</a><a href="customer_registration.php" style="color:white; list-style:none;">Register</a><input type="submit" class="btn btn-success" style="float:right;">
									</form>
								</div>
								<div class="panel-footer" id="e_msg"></div>
							</div>
						</div>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</div>	
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
		
			</div>
			<b><h1>Our Terms & Policies</h1></b> </br>


<br/>
<b>1. Music </b>
Taj Masala restaurent is complete discretion of music and noise levels at all times, to vary or cease entertainment levels that don't comply with applicable licensing laws, or which may cause The Malaya to breach the lease agreement. In the case of dispute between patrons and The Malaya concerning the nature of any music / entertainment or the noise levels of such music / entertainment, the decision of The Malaya shall be absolute and final.
</br>
<br/>
<b>2. Final arrangements</b> 
All food & beverage orders in writing, and any other arrangements are required 7 days prior to your function.
</br>
<br/>
<b>3. Numbers </b>
Guaranteed numbers in writing are required 24 hours prior to your function. The charges will apply to guaranteed minimum numbers, or the final head count, which ever is greater.
</br>

<br/>
<b>4. Accounts </b>
Private dining reservations made more than six weeks in advance are required to provide a 50% deposit (of minimum spend requirements) within 7 days of a tentative booking being made. Full payment of the minimum expenditure must be paid in full 14 days prior to the function date. Payment can be made through Paypal or EFT. Amount incurred above the minimum specified will be charged on consumption basis and must be settled on the day. If payment is not received by the due date, the booking will be cancelled.
</br>

<br/>
<b>5. Cancellation </b>
Cancellation of a private function space within 2 weeks of the function date results in forfeiture of all monies paid. Cancellation must be made in writing to Johanna or Tri Le at The Malaya. Cancellation of a reservation in the main dining area for 8 people or more within 24 hours of dining results in a charge to the credit card held of $50.00 per seat reserved.
</br>
<br/>
<b>6. Liquor and Beverages </b>
Management reserves all rights to supply liquor and beverages. The Malaya is committed to the responsible service of alcohol. Intoxicated guests will not be served. Consumption must comply with all local council and state regulations.
</br>

<br/>
<b>7. Menu</b> 
If you or any member or your group have any food allergies please advise management prior to your reservation. We will do our best to accommodate requests, although this cannot be guaranteed. All groups of 10 people or more are required to order a set menu. Changes to a set menu can be made by prearrangement only. 
</br>		</div>
	</div>
</body>
</html>
















































